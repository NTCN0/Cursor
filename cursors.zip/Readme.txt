FRANCAIS :

Pour installer les curseurs, suivez les �tapes ci-dessous :
	_ Copiez tous les fichiers de l'archive dans un dossier temporaire
	_ Faites un clic droit sur le fichier "Cursor_installation.inf" puis choisissez l'option "Installer"
	_ Ouvrez le Panneau de Configuration de Windows (dans le menu D�marrer), et choisissez la vue classique
	_ Double-cliquez sur "Souris"
	_ Ouvrez l'onglet "Pointeurs"
	_ S�lectionnez "Tails the Fox" dans la liste des mod�les, puis validez avec OK
	_ Enjoy ;)



ENGLISH:

To install cursors, follow this steps:
	_ Extract all files in a temporary folder
	_ Right click on the file "Cursor_installation.inf" and choose "Install" command
	_ Open the Windows Control Panel (in the Start menu), and choose Classic view
	_ Double-click on "Mouse"
	_ Open "Pointers" tab
	_ Select "Tails the Fox" in the models list, then apply with OK button
	_ Enjoy ;)